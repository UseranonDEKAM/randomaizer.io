import json
import random
import os
import customtkinter as ctk
from tkinter import messagebox

ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")

IDEAS_FILE = "ideas.json"

# Базові ідеї (можна буде оновити через інтерфейс)
def load_ideas():
    if not os.path.exists(IDEAS_FILE):
        with open(IDEAS_FILE, "w", encoding="utf-8") as f:
            json.dump([], f, indent=4, ensure_ascii=False)
    with open(IDEAS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_ideas(ideas):
    with open(IDEAS_FILE, "w", encoding="utf-8") as f:
        json.dump(ideas, f, indent=4, ensure_ascii=False)

ideas = load_ideas()
favorites = []

class IdeaApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Що б такого зробити?")
        self.geometry("700x600")

        self.current_idea = None

        self.place_filter = ctk.CTkOptionMenu(self, values=["будь-яке", "вдома", "на вулиці", "онлайн"])
        self.place_filter.set("будь-яке")
        self.place_filter.pack(pady=5)

        self.budget_filter = ctk.CTkOptionMenu(self, values=["будь-який", "безкоштовно", "до 100 грн", "до 500 грн"])
        self.budget_filter.set("будь-який")
        self.budget_filter.pack(pady=5)

        self.duration_filter = ctk.CTkOptionMenu(self, values=["будь-яка", "до 15 хв", "30–60 хв", "понад годину"])
        self.duration_filter.set("будь-яка")
        self.duration_filter.pack(pady=5)

        self.type_filter = ctk.CTkOptionMenu(self, values=["будь-який", "активна", "спокійна", "для компанії"])
        self.type_filter.set("будь-який")
        self.type_filter.pack(pady=5)

        self.idea_label = ctk.CTkLabel(self, text="Натисни, щоб згенерувати ідею!", wraplength=500, font=("Arial", 18), justify="center")
        self.idea_label.pack(pady=20)

        self.generate_button = ctk.CTkButton(self, text="Згенерувати!", command=self.generate_idea)
        self.generate_button.pack(pady=10)

        self.new_button = ctk.CTkButton(self, text="Мені не подобається — іншу!", command=self.generate_idea)
        self.new_button.pack(pady=5)

        self.save_button = ctk.CTkButton(self, text="Зберегти в улюблене", command=self.save_to_favorites)
        self.save_button.pack(pady=5)

        self.add_button = ctk.CTkButton(self, text="Додати свою ідею", command=self.open_add_window)
        self.add_button.pack(pady=5)

        self.fav_button = ctk.CTkButton(self, text="Мої улюблені", command=self.open_favorites_window)
        self.fav_button.pack(pady=5)

    def generate_idea(self):
        global ideas
        filtered = [i for i in ideas if
            (self.place_filter.get() == "будь-яке" or i["місце"] == self.place_filter.get()) and
            (self.budget_filter.get() == "будь-який" or i["бюджет"] == self.budget_filter.get()) and
            (self.duration_filter.get() == "будь-яка" or i["тривалість"] == self.duration_filter.get()) and
            (self.type_filter.get() == "будь-який" or i["тип"] == self.type_filter.get())
        ]
        if filtered:
            self.current_idea = random.choice(filtered)
            self.idea_label.configure(text=f'{self.current_idea["назва"]}\n\n{self.current_idea["опис"]}')
        else:
            self.idea_label.configure(text="Нічого не знайдено за обраними фільтрами :(")

    def save_to_favorites(self):
        if self.current_idea and self.current_idea not in favorites:
            favorites.append(self.current_idea)
            messagebox.showinfo("Збережено", "Ідею додано до улюблених!")

    def open_add_window(self):
        add_window = ctk.CTkToplevel(self)
        add_window.title("Додати свою ідею")
        add_window.geometry("400x400")

        title_entry = ctk.CTkEntry(add_window, placeholder_text="Назва")
        title_entry.pack(pady=5)

        desc_entry = ctk.CTkEntry(add_window, placeholder_text="Опис")
        desc_entry.pack(pady=5)

        place = ctk.CTkOptionMenu(add_window, values=["вдома", "на вулиці", "онлайн"])
        place.set("вдома")
        place.pack(pady=5)

        budget = ctk.CTkOptionMenu(add_window, values=["безкоштовно", "до 100 грн", "до 500 грн"])
        budget.set("безкоштовно")
        budget.pack(pady=5)

        duration = ctk.CTkOptionMenu(add_window, values=["до 15 хв", "30–60 хв", "понад годину"])
        duration.set("до 15 хв")
        duration.pack(pady=5)

        act_type = ctk.CTkOptionMenu(add_window, values=["активна", "спокійна", "для компанії"])
        act_type.set("спокійна")
        act_type.pack(pady=5)

        def save_custom():
            new_idea = {
                "назва": title_entry.get(),
                "опис": desc_entry.get(),
                "місце": place.get(),
                "бюджет": budget.get(),
                "тривалість": duration.get(),
                "тип": act_type.get()
            }
            ideas.append(new_idea)
            save_ideas(ideas)
            messagebox.showinfo("Збережено", "Ідею додано!")
            add_window.destroy()

        save_btn = ctk.CTkButton(add_window, text="Зберегти", command=save_custom)
        save_btn.pack(pady=10)

    def open_favorites_window(self):
        fav_window = ctk.CTkToplevel(self)
        fav_window.title("Улюблені ідеї")
        fav_window.geometry("400x400")

        for idea in favorites:
            ctk.CTkLabel(fav_window, text=f'{idea["назва"]}: {idea["опис"]}', wraplength=350).pack(pady=5)


if __name__ == "__main__":
    app = IdeaApp()
    app.mainloop()
